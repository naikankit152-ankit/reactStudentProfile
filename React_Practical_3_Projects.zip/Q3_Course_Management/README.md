# Practical Question 3 - Student Course Management Application

## Concepts demonstrated
- React Router navigation
- Home, Courses and About pages
- Dynamic route: `/course/:id`
- Multiple usable dynamic URLs:
  - `/course/react`
  - `/course/machine-learning`
  - `/course/database-systems`
- Context API for shared student information
- Functional components and JSX

## Run
```bash
npm install
npm run dev
```
