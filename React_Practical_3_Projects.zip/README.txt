REACT PRACTICAL PROJECTS

Q1_Student_Profile
- Functional Student component
- Props: name, course, college
- Two Student components displayed from App

Q2_Student_Registration
- useState
- Controlled Name, Email, Course fields
- Submitted details shown below form
- CSS Modules styling

Q3_Course_Management
- Home, Courses, About
- React Router
- Dynamic /course/:id route
- Context API shared student information
- Functional components and JSX

For each project:
1. Open the project folder in VS Code.
2. Run: npm install
3. Run: npm run dev
4. Open the localhost URL shown by Vite.
