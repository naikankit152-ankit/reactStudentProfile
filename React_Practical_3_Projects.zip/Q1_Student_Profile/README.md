# Practical Question 1 - Student Profile

## Concepts demonstrated
- React functional component
- Props
- JSX
- Reusable components

## Run
```bash
npm install
npm run dev
```

`App.jsx` renders two `Student` components and passes `name`, `course`, and `college` as props.
