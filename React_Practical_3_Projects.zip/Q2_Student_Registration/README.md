# Practical Question 2 - Student Registration Form

## Concepts demonstrated
- `useState`
- Controlled components (`value` + `onChange`)
- Form submission
- Conditional rendering
- CSS Modules

## Run
```bash
npm install
npm run dev
```

After submission, the student details are displayed below the form.
